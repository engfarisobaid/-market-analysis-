"""Indicators, scoring, price plan, ranking. Pure computation on the local DB - no network."""
import json, math, statistics, datetime as dt
from db import connect, get_meta, now_iso
from sources import MARKET_ETFS

MODES = {
    "balanced":   dict(label="Balanced", financial=.20, technical=.25, valuation=.15, analyst=.15, news=.10, growth=.05, risk=.10),
    "investment": dict(label="Investment", financial=.30, technical=.05, valuation=.20, analyst=.10, news=.05, growth=.20, risk=.10),
    "swing":      dict(label="Swing", financial=.10, technical=.30, valuation=.05, analyst=.15, news=.20, growth=.05, risk=.15),
    "trading":    dict(label="Trading", financial=.05, technical=.40, valuation=.05, analyst=.10, news=.20, growth=.05, risk=.15),
}
COMPONENTS = ["financial", "technical", "valuation", "analyst", "news", "growth", "risk"]
POS = ["beat", "beats", "raises", "raised", "upgrade", "upgraded", "record", "surge", "surges", "soar", "approval", "approved", "wins", "win", "contract", "partnership", "launch", "growth", "strong", "buyback", "outperform", "expands"]
NEG = ["miss", "misses", "cuts", "cut", "downgrade", "downgraded", "lawsuit", "probe", "investigation", "recall", "plunge", "plunges", "fraud", "bankruptcy", "layoffs", "warning", "delay", "halt", "default", "slump", "falls", "sec charges"]


def clamp(v, lo, hi): return max(lo, min(hi, v))
def r1(v): return None if v is None else round(v, 1)


def lin(x, lo, hi):
    if x is None: return None
    if hi == lo: return 50.0
    return clamp((x - lo) / (hi - lo) * 100, 0, 100)


def wavg(pairs):
    num = den = 0.0
    for s, w in pairs:
        if s is None: continue
        num += s * w; den += w
    return num / den if den else None


# ---------------------------------------------------------------- indicators
def sma(v, n): return sum(v[-n:]) / n if len(v) >= n else None


def sma_series(v, n):
    out, s = [None] * len(v), 0.0
    for i, x in enumerate(v):
        s += x
        if i >= n: s -= v[i - n]
        if i >= n - 1: out[i] = s / n
    return out


def ema_series(v, n):
    k = 2 / (n + 1); e = v[0]; out = [e]
    for x in v[1:]:
        e = x * k + e * (1 - k); out.append(e)
    return out


def rsi(c, n=14):
    if len(c) < n + 1: return None
    g = l = 0.0
    for i in range(1, n + 1):
        d = c[i] - c[i - 1]; g += max(d, 0); l += max(-d, 0)
    ag, al = g / n, l / n
    for i in range(n + 1, len(c)):
        d = c[i] - c[i - 1]
        ag = (ag * (n - 1) + max(d, 0)) / n; al = (al * (n - 1) + max(-d, 0)) / n
    return 100.0 if al == 0 else 100 - 100 / (1 + ag / al)


def atr(h, l, c, n=14):
    trs = [max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])) for i in range(1, len(c))]
    if len(trs) < n: return None
    a = sum(trs[:n]) / n
    for t in trs[n:]: a = (a * (n - 1) + t) / n
    return a


def adx(h, l, c, n=14):
    if len(c) < 2 * n + 2: return None
    pdm, ndm, tr = [], [], []
    for i in range(1, len(c)):
        up, dn = h[i] - h[i - 1], l[i - 1] - l[i]
        pdm.append(up if up > dn and up > 0 else 0.0); ndm.append(dn if dn > up and dn > 0 else 0.0)
        tr.append(max(h[i] - l[i], abs(h[i] - c[i - 1]), abs(l[i] - c[i - 1])))

    def wilder(x):
        s = sum(x[:n]); out = [s]
        for v in x[n:]:
            s = s - s / n + v; out.append(s)
        return out
    T, P, M = wilder(tr), wilder(pdm), wilder(ndm)
    dx = []
    for a, b, m in zip(T, P, M):
        if a == 0: dx.append(0.0); continue
        pi, ni = 100 * b / a, 100 * m / a
        dx.append(0.0 if pi + ni == 0 else 100 * abs(pi - ni) / (pi + ni))
    if len(dx) < n: return None
    a = sum(dx[:n]) / n
    for v in dx[n:]: a = (a * (n - 1) + v) / n
    return a


def macd(c):
    if len(c) < 40: return None
    e12, e26 = ema_series(c, 12), ema_series(c, 26)
    line = [a - b for a, b in zip(e12, e26)]
    sig = ema_series(line, 9)
    hist = [a - b for a, b in zip(line, sig)]
    return dict(line=line[-1], signal=sig[-1], hist=hist[-1], prev_hist=hist[-2])


def levels(h, l, price, look=170, w=4):
    n = len(h); pts = []
    for i in range(max(w, n - look), n - w):
        if h[i] == max(h[i - w:i + w + 1]): pts.append(h[i])
        if l[i] == min(l[i - w:i + w + 1]): pts.append(l[i])
    groups = []
    for x in sorted(pts):
        if groups and abs(x - groups[-1][-1]) / groups[-1][-1] < 0.015: groups[-1].append(x)
        else: groups.append([x])
    lv = [(sum(g) / len(g), len(g)) for g in groups]
    sup = sorted([x for x in lv if x[0] < price * 0.997], reverse=True)[:3]
    res = sorted([x for x in lv if x[0] > price * 1.003])[:3]
    return sup, res


def human_range(days):
    lo, hi = max(1, round(days * 0.7)), max(2, round(days * 1.4))
    if hi <= 10: return f"{lo}–{hi} trading days"
    if hi <= 40: return f"{max(1, round(lo / 5))}–{round(hi / 5)} weeks"
    return f"{max(1, round(lo / 21))}–{max(2, round(hi / 21))} months"


def horizon_category(days):
    if days <= 5: return "VERY SHORT TERM (1–5 trading days)"
    if days <= 20: return "SHORT TERM (1–4 weeks)"
    if days <= 63: return "SWING TRADE (1–3 months)"
    if days <= 126: return "MEDIUM TERM (3–6 months)"
    return "LONG TERM (6–12+ months)"


def technical(bars, spy_ret6):
    if len(bars) < 200: return None
    c = [b[4] for b in bars]; h = [b[2] for b in bars]; l = [b[3] for b in bars]; v = [b[5] for b in bars]; o = [b[1] for b in bars]
    price = c[-1]
    s20, s50, s100, s200 = sma(c, 20), sma(c, 50), sma(c, 100), sma(c, 200)
    e21 = ema_series(c, 21)[-1]
    rs, mc, a, ad = rsi(c), macd(c), atr(h, l, c), adx(h, l, c)
    if a is None or mc is None or rs is None: return None
    avgvol = sum(v[-50:]) / 50
    relvol = v[-1] / avgvol if avgvol else None
    adv = sum(c[i] * v[i] for i in range(-50, 0)) / 50
    hi52, lo52 = max(h[-252:]), min(l[-252:])
    ret = lambda n: (c[-1] / c[-1 - n] - 1) if len(c) > n else None
    r1m, r3m, r6m = ret(21), ret(63), ret(126)
    rets = [c[i] / c[i - 1] - 1 for i in range(max(1, len(c) - 126), len(c))]
    sigma = statistics.pstdev(rets) if len(rets) > 20 else a / price
    sup, res = levels(h, l, price)
    prior_hi = max(h[-21:-1]); prior_lo = min(l[-21:-1])
    raw_breakout = price > prior_hi
    breakout_ok = raw_breakout and relvol is not None and relvol >= 1.3
    breakdown = price < prior_lo
    obv = 0.0; obvs = [0.0]
    for i in range(1, len(c)):
        obv += v[i] if c[i] > c[i - 1] else (-v[i] if c[i] < c[i - 1] else 0); obvs.append(obv)
    obv_up = (obvs[-1] - obvs[-21]) > 0
    bullish = price > s50 > s200 and s20 > s50 * 0.99
    bearish = price < s50 < s200
    trend = "Bullish" if bullish else "Bearish" if bearish else "Neutral"
    overext = price > s50 * 1.15 or rs > 78
    pullback = (price > s200 and s50 > s200) and (abs(price / s20 - 1) < 0.03 or abs(price / s50 - 1) < 0.04) and rs < 58
    gap = abs(o[-1] / c[-2] - 1) > 0.03
    rs_vs_spy = (r6m - spy_ret6) if r6m is not None else None
    t = 50.0
    t += 8 if price > s20 else -4
    t += 10 if price > s50 else -10
    t += 10 if price > s200 else -12
    t += 6 if s50 > s200 else -6
    t += 5 if s20 > s50 else -3
    if r3m is not None: t += clamp(r3m * 60, -10, 10)
    if rs_vs_spy is not None: t += clamp(rs_vs_spy * 30, -8, 8)
    t += 5 if mc["hist"] > 0 else -5
    t += 3 if mc["hist"] > mc["prev_hist"] else -2
    if 45 <= rs <= 68: t += 4
    elif rs > 78: t -= 8
    elif rs > 70: t -= 3
    elif rs < 30: t -= 4
    if ad is not None and ad > 25: t += 4 if bullish else (-4 if bearish else 0)
    if breakout_ok: t += 8
    elif raw_breakout: t += 2
    if relvol and relvol > 1.3 and c[-1] > c[-2]: t += 3
    t += 3 if obv_up else -2
    if res:
        d = res[0][0] / price - 1
        t += -5 if d < 0.02 else (3 if d > 0.08 else 0)
    if breakdown: t -= 12
    if overext: t -= 6
    return dict(
        price=price, date=bars[-1][0], chg1d=(c[-1] / c[-2] - 1) * 100, sma20=s20, sma50=s50, sma100=s100, sma200=s200, ema21=e21,
        rsi=rs, macd=mc, atr=a, atr_pct=a / price * 100, adx=ad, avgvol=avgvol, relvol=relvol, adv=adv, hi52=hi52, lo52=lo52,
        ret1m=r1m, ret3m=r3m, ret6m=r6m, rs_vs_spy=rs_vs_spy, sigma=sigma, supports=sup, resistances=res,
        breakout=raw_breakout, breakout_confirmed=breakout_ok, breakdown=breakdown, obv_up=obv_up, trend=trend,
        overextended=overext, pullback=pullback, gap=gap, score=clamp(t, 3, 97),
        macd_cross_up=mc["hist"] > 0 >= mc["prev_hist"], macd_cross_dn=mc["hist"] < 0 <= mc["prev_hist"],
        from_high=(price / hi52 - 1) * 100,
    )


# -------------------------------------------------------------- fundamentals
def fund_metrics(f, price):
    g = lambda k: f.get(k)
    rev, revp, rev2 = g("revenue"), g("revenue_prev"), g("revenue_2y")
    ni, eps, epsp = g("net_income"), g("eps"), g("eps_prev")
    rg = (rev / revp - 1) * 100 if rev and revp and revp > 0 else None
    cagr2 = ((rev / rev2) ** 0.5 - 1) * 100 if rev and rev2 and rev2 > 0 and rev > 0 else None
    epsg = None
    if eps is not None and epsp is not None and epsp != 0:
        epsg = clamp((eps - epsp) / abs(epsp) * 100, -150, 150)
    fcf = g("ocf") - (g("capex") or 0) if g("ocf") is not None and g("capex") is not None else None
    eq = g("equity")
    shares = g("shares_out") or g("shares_w")
    mcap = price * shares if shares else None
    pe = price / eps if eps and eps > 0 else None
    sh, shp = g("shares_w"), g("shares_w_prev")
    return dict(
        revenue=rev, net_income=ni, eps=eps, revenue_growth=rg, revenue_cagr2=cagr2, eps_growth=epsg,
        gross_margin=(g("gross_profit") / rev * 100) if g("gross_profit") is not None and rev else None,
        operating_margin=(g("operating_income") / rev * 100) if g("operating_income") is not None and rev else None,
        net_margin=(ni / rev * 100) if ni is not None and rev else None,
        fcf=fcf, fcf_margin=(fcf / rev * 100) if fcf is not None and rev else None, ocf=g("ocf"),
        roe=(ni / eq * 100) if ni is not None and eq and eq > 0 else None,
        debt_equity=(g("debt") / eq) if g("debt") is not None and eq and eq > 0 else None,
        liabilities_equity=(g("liabilities") / eq) if g("liabilities") is not None and eq and eq > 0 else None,
        current_ratio=(g("current_assets") / g("current_liabilities")) if g("current_assets") and g("current_liabilities") else None,
        total_debt=g("debt"), cash=g("cash"),
        dilution=((sh / shp - 1) * 100) if sh and shp else None,
        buyback=g("buyback"), dividends=g("dividends"),
        mcap=mcap, pe=pe, ps=(mcap / rev) if mcap and rev and rev > 0 else None,
        fcf_yield=(fcf / mcap * 100) if fcf is not None and mcap else None,
        peg=(pe / epsg) if pe and epsg and epsg > 0 else None,
        fiscal_end=g("fiscal_end"), history=g("history") or [],
    )


def financial_score(m):
    de = m["debt_equity"] if m["debt_equity"] is not None else m["liabilities_equity"]
    s = wavg([
        (lin(m["net_margin"], -5, 25), 1.2), (lin(m["operating_margin"], -5, 30), 1.0), (lin(m["roe"], 0, 25), 1.0),
        (lin(m["fcf_margin"], -5, 25), 1.4), (lin(de, 2.5 if m["debt_equity"] is not None else 6, 0.2), 1.0),
        (lin(m["current_ratio"], 0.8, 2.0), 0.6), (lin(m["revenue_growth"], -5, 25), 1.0),
        (lin(m["eps_growth"], -10, 30), 0.8), (lin(m["dilution"], 8, -2), 0.6)])
    if s is None: return None
    if m["net_income"] is not None and m["net_income"] < 0: s -= 8
    if m["ocf"] is not None and m["ocf"] < 0: s -= 6
    return clamp(s, 3, 97)


def growth_score(m):
    s = wavg([(lin(m["revenue_growth"], -5, 30), 1.2), (lin(m["eps_growth"], -10, 40), 1.0), (lin(m["revenue_cagr2"], 0, 25), 0.8)])
    return None if s is None else clamp(s, 3, 97)


def growth_label(s):
    return "High Growth" if s >= 75 else "Moderate Growth" if s >= 55 else "Low Growth" if s >= 35 else "Declining"


def valuation_score(m, sector_pe):
    rel = (m["pe"] / sector_pe) if m["pe"] and sector_pe else None
    s = wavg([(lin(m["pe"], 40, 10), 1.2), (lin(m["ps"], 15, 1), 0.6), (lin(m["fcf_yield"], 0, 7), 1.2),
              (lin(m["peg"], 3, 0.8), 1.0), (lin(rel, 1.6, 0.6), 1.0)])
    if s is None: return None
    if m["pe"] is None: s *= 0.85
    return clamp(s, 3, 97)


def risk_score(t, m, beta, earn_days):
    de = m["debt_equity"] if m["debt_equity"] is not None else (m["liabilities_equity"] / 2.5 if m["liabilities_equity"] else None)
    s = wavg([(lin(t["atr_pct"], 7, 1.5), 1.4), (lin(beta, 2.0, 0.7), 1.0), (lin(-t["from_high"], 50, 5), 0.8),
              (lin(de, 2.5, 0.2), 0.8), (lin(t["adv"], 5e6, 2e8), 0.8)])
    if s is None: s = 50.0
    if m["net_income"] is not None and m["net_income"] < 0: s -= 10
    if m["fcf"] is not None and m["fcf"] < 0: s -= 6
    if earn_days is not None and 0 <= earn_days <= 7: s -= 8
    if t["trend"] == "Bearish": s -= 6
    return clamp(s, 3, 97)


def analyst_info(a):
    rec = (a or {}).get("rec") or []
    if not rec: return None
    f = lambda r: (r.get("strongBuy", 0), r.get("buy", 0), r.get("hold", 0), r.get("sell", 0), r.get("strongSell", 0))
    sb, b, h, s, ss = f(rec[0]); n = sb + b + h + s + ss
    if n == 0: return None
    net = lambda r: (2 * r.get("strongBuy", 0) + r.get("buy", 0) - r.get("sell", 0) - 2 * r.get("strongSell", 0)) / max(1, sum(f(r)))
    score = 50 + 25 * net(rec[0])
    score = 50 + (score - 50) * min(1.0, n / 10)
    drift = (net(rec[0]) - net(rec[1])) if len(rec) > 1 and sum(f(rec[1])) else 0.0
    score = clamp(score + clamp(drift * 15, -8, 8), 3, 97)
    return dict(score=score, n=n, strong_buy=sb, buy=b, hold=h, sell=s, strong_sell=ss, drift=drift, period=rec[0].get("period"))


def news_info(items, earn_days):
    if not items: return None
    pos = neg = 0
    for it in items:
        words = set(w.strip(".,:;!?\"'()").lower() for w in it["headline"].split())
        low = it["headline"].lower()
        p = any(w in words for w in POS); q = any(w in words for w in NEG) or "sec charges" in low
        pos += 1 if p and not q else 0; neg += 1 if q and not p else 0
    tot = pos + neg
    net = (pos - neg) / tot if tot else 0.0
    score = 50 + 45 * net * min(1.0, tot / 4)
    label = "VERY POSITIVE" if score >= 72 else "POSITIVE" if score >= 58 else "NEUTRAL" if score >= 42 else "NEGATIVE" if score >= 28 else "VERY NEGATIVE"
    impact = "HIGH" if (tot >= 5 and abs(net) >= 0.5) or (earn_days is not None and earn_days <= 14) else "MEDIUM" if tot >= 2 else "LOW"
    return dict(score=score if tot else None, label=label if tot else "NEUTRAL", impact=impact, pos=pos, neg=neg, count=len(items), items=items[:6])


def earnings_days(a):
    for e in (a or {}).get("earnings") or []:
        try:
            d = (dt.date.fromisoformat(e["date"]) - dt.date.today()).days
            if d >= 0: return d, e["date"]
        except Exception:
            continue
    return None, None


# --------------------------------------------------------------- base build
def load_bars(con, t, limit=420):
    return con.execute("SELECT date,open,high,low,close,volume FROM prices WHERE ticker=? ORDER BY date DESC LIMIT ?", (t, limit)).fetchall()[::-1]


def build_base(cfg, progress=None):
    con = connect(cfg)
    spy = load_bars(con, "SPY")
    spy_ret6 = (spy[-1][4] / spy[-127][4] - 1) if len(spy) >= 127 else 0.0
    spy_rets = {spy[i][0]: spy[i][4] / spy[i - 1][4] - 1 for i in range(1, len(spy))}
    latest = get_meta(con, "prices_last_date") or (con.execute("SELECT MAX(date) FROM prices").fetchone()[0])
    funds = {r[0]: (json.loads(r[1]), r[2]) for r in con.execute("SELECT ticker,data,fetched FROM fundamentals")}
    ana = {r[0]: (json.loads(r[1]), r[2]) for r in con.execute("SELECT ticker,data,fetched FROM analyst")}
    nws = {r[0]: (json.loads(r[1]), r[2]) for r in con.execute("SELECT ticker,data,fetched FROM news")}
    quotes = {r[0]: dict(price=r[1], ts=r[2], fetched=r[3]) for r in con.execute("SELECT ticker,price,ts,fetched FROM quotes")}
    uni = con.execute("SELECT ticker,name,exchange,sector,industry FROM universe WHERE is_etf=0").fetchall()
    excl = dict(no_price_data=0, insufficient_history=0, stale_price=0, penny_or_illiquid=0, no_fundamentals=0)
    out = []
    if not latest:
        return dict(base=[], excl=excl, analyzed=0, latest=None, spy=spy)
    lim = dt.date.fromisoformat(latest) - dt.timedelta(days=cfg["max_stale_days"])
    analyzed = 0
    for t, name, exch, sector, industry in uni:
        bars = load_bars(con, t)
        if not bars: excl["no_price_data"] += 1; continue
        analyzed += 1
        if len(bars) < 200: excl["insufficient_history"] += 1; continue
        if dt.date.fromisoformat(bars[-1][0]) < lim: excl["stale_price"] += 1; continue
        tech = technical(bars, spy_ret6)
        if not tech: excl["insufficient_history"] += 1; continue
        if tech["price"] < cfg["min_price"] or tech["adv"] < cfg["min_avg_dollar_volume"]: excl["penny_or_illiquid"] += 1; continue
        fd = funds.get(t)
        if not fd or fd[0].get("unavailable"): excl["no_fundamentals"] += 1; continue
        fm = fund_metrics(fd[0], tech["price"])
        fin = financial_score(fm)
        if fin is None: excl["no_fundamentals"] += 1; continue
        closes = [b[4] for b in bars]
        pairs = [(spy_rets[bars[i][0]], closes[i] / closes[i - 1] - 1) for i in range(1, len(bars)) if bars[i][0] in spy_rets]
        beta = None
        if len(pairs) > 60:
            xs, ys = zip(*pairs[-252:]); mx, my = sum(xs) / len(xs), sum(ys) / len(ys)
            vx = sum((x - mx) ** 2 for x in xs)
            beta = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / vx if vx else None
        a_raw = ana.get(t, (None, None))[0]
        ed, edate = earnings_days(a_raw)
        out.append(dict(ticker=t, name=name, exchange=exch, sector=sector or "Other", industry=industry, price=tech["price"], last_date=bars[-1][0],
                        tech=tech, fm=fm, beta=beta, fin=fin, analyst=analyst_info(a_raw), analyst_fetched=ana.get(t, (None, None))[1],
                        news=news_info(nws.get(t, (None, None))[0], ed), earn_days=ed, earn_date=edate, quote=quotes.get(t),
                        fund_fetched=fd[1], closes=closes[-260:], dates=[b[0] for b in bars][-260:], vols=[b[5] for b in bars][-260:]))
    # sector medians and valuation / risk / growth
    pes = {}
    for b in out:
        if b["fm"]["pe"] and 0 < b["fm"]["pe"] < 200: pes.setdefault(b["sector"], []).append(b["fm"]["pe"])
    allpe = [x for v in pes.values() for x in v]
    gmed = statistics.median(allpe) if allpe else None
    for b in out:
        lst = pes.get(b["sector"], [])
        b["sector_pe"] = statistics.median(lst) if len(lst) >= 8 else gmed
        val = valuation_score(b["fm"], b["sector_pe"])
        # false-signal rule: cheap + bearish trend is not an automatic buy
        b["value_trap"] = bool(val is not None and val >= 65 and b["tech"]["trend"] == "Bearish")
        if b["value_trap"]: val = min(val, 55)
        gro = growth_score(b["fm"])
        b["sub"] = dict(financial=b["fin"], technical=b["tech"]["score"], valuation=val if val is not None else 50.0,
                        growth=gro if gro is not None else 50.0, risk=risk_score(b["tech"], b["fm"], b["beta"], b["earn_days"]),
                        analyst=b["analyst"]["score"] if b["analyst"] else None, news=b["news"]["score"] if b["news"] and b["news"]["score"] is not None else None)
        b["valuation_known"] = val is not None
        b["val_label"] = "Undervalued" if b["sub"]["valuation"] >= 65 else "Overvalued" if b["sub"]["valuation"] <= 40 else "Fairly Valued"
        b["growth_label"] = growth_label(b["sub"]["growth"])
    return dict(base=out, excl=excl, analyzed=analyzed, latest=latest, spy=spy)


# ------------------------------------------------------------------- market
def market_overview(cfg, base):
    con = connect(cfg)
    idx = []
    for sym in MARKET_ETFS:
        bars = load_bars(con, sym, 260)
        if len(bars) < 2:
            idx.append(dict(symbol=sym, available=False)); continue
        c = [b[4] for b in bars]
        q = con.execute("SELECT price,ts FROM quotes WHERE ticker=?", (sym,)).fetchone()
        idx.append(dict(symbol=sym, available=True, close=c[-1], chg1d=(c[-1] / c[-2] - 1) * 100, date=bars[-1][0],
                        sma50=sma(c, 50), sma200=sma(c, 200), quote=q[0] if q else None, quote_ts=q[1] if q else None))
    n = len(base) or 1
    breadth50 = 100 * sum(1 for b in base if b["price"] > b["tech"]["sma50"]) / n
    breadth200 = 100 * sum(1 for b in base if b["price"] > b["tech"]["sma200"]) / n
    adv = sum(1 for b in base if b["tech"]["chg1d"] > 0); dec = sum(1 for b in base if b["tech"]["chg1d"] < 0)
    spy = next((i for i in idx if i["symbol"] == "SPY" and i["available"]), None)
    cond = "Neutral"
    if spy and spy["sma50"] and spy["sma200"]:
        if spy["close"] > spy["sma50"] > spy["sma200"]: cond = "Bullish"
        elif spy["close"] < spy["sma50"] and spy["close"] < spy["sma200"]: cond = "Bearish"
        if cond == "Bullish" and breadth50 < 40: cond = "Neutral"
        if cond == "Neutral" and breadth50 < 30: cond = "Bearish"
    elif base:
        cond = "Bullish" if breadth50 > 60 else "Bearish" if breadth50 < 35 else "Neutral"
    return dict(indices=idx, breadth50=breadth50, breadth200=breadth200, advancers=adv, decliners=dec, condition=cond if base else "Unavailable")


def sector_table(base):
    rows = {}
    for b in base: rows.setdefault(b["sector"], []).append(b)
    out = []
    for sec, lst in rows.items():
        if len(lst) < 3: continue
        r3 = statistics.mean([b["tech"]["ret3m"] for b in lst if b["tech"]["ret3m"] is not None] or [0]) * 100
        p50 = 100 * sum(1 for b in lst if b["price"] > b["tech"]["sma50"]) / len(lst)
        med_pe = statistics.median([b["fm"]["pe"] for b in lst if b["fm"]["pe"] and 0 < b["fm"]["pe"] < 200] or [0]) or None
        strength = 0.5 * lin(r3, -10, 15) + 0.5 * p50
        out.append(dict(sector=sec, n=len(lst), ret3m=r3, pct_above50=p50, median_pe=med_pe, strength=strength))
    return sorted(out, key=lambda x: -x["strength"])


# ---------------------------------------------------------------- evaluation
def make_plan(b):
    t = b["tech"]; price, a = t["price"], t["atr"]
    s1 = t["supports"][0][0] if t["supports"] else price - 2.5 * a
    if t["breakout_confirmed"]: lo, hi = price - 0.3 * a, price + 0.3 * a
    else: lo, hi = max(s1, price - 0.9 * a), price + 0.15 * a
    lo = min(lo, price); mid = (lo + hi) / 2
    stop = min(s1 - 0.5 * a, mid - 2.0 * a)
    capped = (mid - stop) > 0.15 * mid
    if capped: stop = mid - 0.15 * mid
    risk = mid - stop
    cands = [p for p, _ in t["resistances"] if p > price + 1.2 * a]
    t1 = cands[0] if cands else price + 2.0 * a
    t2 = cands[1] if len(cands) > 1 else max(t1 + 1.5 * a, price + 3.5 * a)
    t3 = cands[2] if len(cands) > 2 else max(t2 + 2.0 * a, price + 6.0 * a)
    t2 = max(t2, t1 + a); t3 = max(t3, t2 + a)
    sigma = max(t["sigma"], 0.004)
    mom = max((t["ret6m"] or 0) / 126, 0.0004) if (t["ret6m"] or 0) > 0 else 0.0004
    def days(tg):
        d = tg / price - 1
        return clamp(math.sqrt((d / sigma) ** 2 * (d / mom)), 3, 500)
    d1, d2, d3 = days(t1), days(t2), days(t3)
    return dict(entry_low=lo, entry_high=hi, stop=stop, stop_capped=capped, t1=t1, t2=t2, t3=t3,
                rr=(t2 - mid) / risk if risk > 0 else 0.0, rr_t1=(t1 - mid) / risk if risk > 0 else 0.0,
                upside=(t2 / price - 1) * 100, risk_pct=risk / mid * 100,
                days=[round(d1), round(d2), round(d3)], time=[human_range(d1), human_range(d2), human_range(d3)],
                horizon=horizon_category(d2), supports=t["supports"], resistances=t["resistances"],
                major_support=max(t["supports"], key=lambda x: (x[1], x[0]))[0] if t["supports"] else None,
                major_resistance=max(t["resistances"], key=lambda x: (x[1], -x[0]))[0] if t["resistances"] else None)


def why_reasons(b, p):
    s, t, m = b["sub"], b["tech"], b["fm"]; r = []
    if s["financial"] >= 68 and m["revenue_growth"] is not None: r.append(f"Strong financials — revenue {m['revenue_growth']:+.1f}% YoY, net margin {m['net_margin'] if m['net_margin'] is not None else float('nan'):.1f}%")
    elif s["financial"] >= 68: r.append("Strong financial profile versus screening thresholds")
    if s["growth"] >= 68 and m["eps_growth"] is not None: r.append(f"{b['growth_label']} — EPS change {m['eps_growth']:+.0f}% YoY")
    if t["breakout_confirmed"]: r.append(f"Confirmed breakout above 20-day high on {t['relvol']:.1f}x average volume")
    elif t["pullback"]: r.append("Pullback to rising moving averages inside an uptrend")
    elif s["technical"] >= 68: r.append("Bullish trend structure (price above 50/200-day averages, positive momentum)")
    if b["val_label"] == "Undervalued": r.append("Valuation screens cheaper than sector peers" + (f" (P/E {m['pe']:.1f} vs sector {b['sector_pe']:.1f})" if m["pe"] and b["sector_pe"] else ""))
    if b["analyst"] and b["analyst"]["score"] >= 65: r.append(f"Analyst consensus leans bullish ({b['analyst']['strong_buy'] + b['analyst']['buy']} of {b['analyst']['n']} Buy or better)")
    if b["news"] and b["news"]["score"] and b["news"]["score"] >= 62: r.append(f"Recent news flow is {b['news']['label'].lower()}")
    if p["rr"] >= 2.5: r.append(f"Attractive risk/reward of about 1:{p['rr']:.1f}")
    if t["rs_vs_spy"] is not None and t["rs_vs_spy"] > 0.08: r.append(f"Outperforming the S&P 500 proxy by {t['rs_vs_spy'] * 100:.0f} pts over 6 months")
    return r[:5] or ["Passes all minimum screens; no standout factor"]


def main_risks(b, p):
    s, t, m = b["sub"], b["tech"], b["fm"]; r = []
    if b["val_label"] == "Overvalued": r.append("Valuation looks rich versus earnings/cash flow" + (f" (P/E {m['pe']:.1f})" if m["pe"] else ""))
    if b["value_trap"]: r.append("Looks cheap but trend is bearish — possible value trap")
    if t["resistances"] and (t["resistances"][0][0] / t["price"] - 1) < 0.03: r.append(f"Resistance close overhead (${t['resistances'][0][0]:.2f})")
    if t["overextended"]: r.append("Price extended from its averages / RSI elevated — pullback risk")
    if s["risk"] < 50: r.append(f"Elevated volatility (ATR {t['atr_pct']:.1f}% of price" + (f", beta {b['beta']:.2f})" if b["beta"] else ")"))
    if m["net_income"] is not None and m["net_income"] < 0: r.append("Company reported a net loss in its latest fiscal year")
    if m["debt_equity"] is not None and m["debt_equity"] > 1.5: r.append(f"High leverage (debt/equity {m['debt_equity']:.1f})")
    if m["dilution"] is not None and m["dilution"] > 4: r.append(f"Share count rising {m['dilution']:.1f}% (dilution)")
    if b["earn_days"] is not None and b["earn_days"] <= 14: r.append(f"Earnings in {b['earn_days']} days — event risk")
    if b["analyst"] and b["analyst"]["drift"] < -0.15: r.append("Analyst ratings drifting lower")
    if b["news"] and b["news"]["score"] is not None and b["news"]["score"] < 40: r.append("Recent headlines skew negative")
    if p["stop_capped"]: r.append("Stop distance capped at 15% — setup is volatile")
    return r[:5] or ["No dominant risk flagged — monitor overall market conditions"]


def invalidation(b, p):
    l = [f"Daily close below stop-loss ${p['stop']:.2f}"]
    if p["major_support"]: l.append(f"Break of major support near ${p['major_support']:.2f}")
    if b["tech"]["breakout_confirmed"]: l.append("Breakout fails and price closes back below the prior 20-day high")
    l.append("Negative earnings surprise or guidance cut")
    l.append("Market regime turns Bearish (S&P 500 proxy loses its 50/200-day averages)")
    return l[:5]


def evaluate(b, mode, market_cond, sec_strength):
    w = MODES[mode]
    s = b["sub"]
    avail = [(s[k], w[k]) for k in COMPONENTS if s.get(k) is not None]
    wsum = sum(x[1] for x in avail)
    coverage = wsum / sum(w[k] for k in COMPONENTS)
    raw = sum(v * ww for v, ww in avail) / wsum
    mkt_adj = {"Bullish": 0.0, "Neutral": -2.0, "Bearish": -7.0}.get(market_cond, 0.0) * (1.5 if mode == "trading" else 1.0)
    sec_adj = ((sec_strength - 50) / 50 * 3) if sec_strength is not None else 0.0
    opp = clamp(raw + mkt_adj + sec_adj, 1, 99)
    vals = [v for v, _ in avail]
    agreement = clamp(100 - statistics.pstdev(vals) * 2.0, 5, 99)
    stale = 0.9 if b["last_date"] < (dt.date.today() - dt.timedelta(days=7)).isoformat() else 1.0
    conf = clamp((agreement * (0.6 + 0.4 * coverage) + {"Bullish": 3, "Neutral": 0, "Bearish": -6}.get(market_cond, 0) + (sec_adj)) * stale, 5, 97)
    plan = make_plan(b)
    quality = "HIGH QUALITY" if s["financial"] >= 60 and s["technical"] >= 60 and (s["analyst"] is None or s["analyst"] >= 55) and agreement >= 65 else "SPECULATIVE"
    rec = "STRONG OPPORTUNITY" if opp >= 80 and conf >= 70 else "OPPORTUNITY" if opp >= 68 else "WATCH" if opp >= 55 else "WEAK"
    risk_label = "Low" if s["risk"] >= 70 else "Medium" if s["risk"] >= 45 else "High"
    rank_score = (0.45 * opp + 0.20 * conf + 0.10 * min(plan["rr"], 4) / 4 * 100 + 0.10 * clamp(plan["upside"], 0, 40) / 40 * 100
                  + 0.075 * s["technical"] + 0.075 * s["financial"])
    gate = None
    if plan["rr"] < 1.5: gate = "risk_reward_below_1.5"
    elif s["risk"] < 25: gate = "abnormal_risk"
    elif b["tech"]["breakdown"] and b["tech"]["trend"] == "Bearish": gate = "bearish_breakdown"
    note = ("Confirmed breakout — consider entry inside the zone, not far above it" if b["tech"]["breakout_confirmed"] else
            "Pullback setup — price is near the entry zone" if b["tech"]["pullback"] else
            "Extended — better entry likely on a pullback" if b["tech"]["overextended"] else
            "Quality business, technical setup not yet confirmed — consider waiting" if s["technical"] < 50 else "Setup in range")
    live = b["quote"]["price"] if b.get("quote") and b["quote"].get("price") else None
    return dict(
        ticker=b["ticker"], name=b["name"], sector=b["sector"], industry=b["industry"], exchange=b["exchange"], price=b["price"], price_date=b["last_date"],
        live_price=live, live_ts=(b["quote"] or {}).get("ts") if live else None, chg1d=b["tech"]["chg1d"],
        opportunity=r1(opp), confidence=r1(conf), subs={k: r1(v) for k, v in s.items()}, weights={k: w[k] for k in COMPONENTS}, coverage=round(coverage, 2),
        mkt_adj=mkt_adj, sec_adj=round(sec_adj, 1), quality=quality, recommendation=rec, risk_label=risk_label, rank_score=rank_score,
        plan=dict(entry_low=r1(plan["entry_low"]), entry_high=r1(plan["entry_high"]), stop=r1(plan["stop"]), t1=r1(plan["t1"]), t2=r1(plan["t2"]), t3=r1(plan["t3"]),
                  rr=r1(plan["rr"]), upside=r1(plan["upside"]), risk_pct=r1(plan["risk_pct"]), time=plan["time"], days=plan["days"], horizon=plan["horizon"],
                  major_support=r1(plan["major_support"]) if plan["major_support"] else None, major_resistance=r1(plan["major_resistance"]) if plan["major_resistance"] else None,
                  stop_capped=plan["stop_capped"], supports=[[r1(x), k] for x, k in plan["supports"]], resistances=[[r1(x), k] for x, k in plan["resistances"]]),
        entry_note=note, gate=gate, why=why_reasons(b, plan), risks=main_risks(b, plan), invalidation=invalidation(b, plan),
        val_label=b["val_label"], growth_label=b["growth_label"], value_trap=b["value_trap"],
        trend=b["tech"]["trend"], breakout=b["tech"]["breakout_confirmed"], earn_days=b["earn_days"], earn_date=b["earn_date"],
    )


# ---------------------------------------------------------------------- scan
_CACHE = {"stamp": None, "data": None}


def get_base(cfg):
    con = connect(cfg)
    stamp = (get_meta(con, "data_stamp"), get_meta(con, "prices_last_import"), get_meta(con, "fundamentals_updated"), get_meta(con, "finnhub_updated"))
    if _CACHE["stamp"] != stamp or _CACHE["data"] is None:
        _CACHE["data"] = build_base(cfg); _CACHE["stamp"] = stamp
    return _CACHE["data"]


def data_status(cfg):
    con = connect(cfg)
    q = lambda s: con.execute(s).fetchone()[0]
    return dict(
        universe=q("SELECT COUNT(*) FROM universe WHERE is_etf=0"), tickers_with_prices=q("SELECT COUNT(DISTINCT ticker) FROM prices"),
        prices_last_date=get_meta(con, "prices_last_date"), prices_imported=get_meta(con, "prices_last_import"),
        fundamentals_count=q("SELECT COUNT(*) FROM fundamentals WHERE data NOT LIKE '%unavailable%'"), fundamentals_updated=get_meta(con, "fundamentals_updated"),
        analyst_count=q("SELECT COUNT(*) FROM analyst"), finnhub_updated=get_meta(con, "finnhub_updated"),
        finnhub_configured=bool(cfg.get("finnhub_api_key", "").strip()))


def run_scan(cfg, mode="balanced", save=False, top_n=30):
    mode = mode if mode in MODES else "balanced"
    bd = get_base(cfg)
    base = bd["base"]
    market = market_overview(cfg, base)
    sectors = sector_table(base)
    sec_strength = {s["sector"]: s["strength"] for s in sectors}
    evals = [evaluate(b, mode, market["condition"], sec_strength.get(b["sector"])) for b in base]
    excl = dict(bd["excl"]); gated = {}
    ranked = []
    for e in sorted(evals, key=lambda x: -x["rank_score"]):
        if e["gate"]: gated[e["gate"]] = gated.get(e["gate"], 0) + 1; continue
        ranked.append(e)
    for i, e in enumerate(ranked): e["rank"] = i + 1
    con = connect(cfg)
    run_id = dt.date.today().isoformat()
    prev = con.execute("SELECT MAX(run_id) FROM rankings WHERE mode=? AND run_id<?", (mode, run_id)).fetchone()[0]
    prev_rows = {}
    if prev:
        for t, rk, op, subs in con.execute("SELECT ticker,rank,opportunity,subs FROM rankings WHERE mode=? AND run_id=?", (mode, prev)):
            prev_rows[t] = (rk, op, json.loads(subs))
    for e in ranked[:top_n * 3]:
        pr = prev_rows.get(e["ticker"])
        e["prev_rank"] = pr[0] if pr else None
        e["rank_change"] = (pr[0] - e["rank"]) if pr else None
        e["score_change"] = round(e["opportunity"] - pr[1], 1) if pr else None
        e["change_why"] = []
        if pr:
            deltas = sorted(((k, (e["subs"].get(k) or 0) - (pr[2].get(k) or 0)) for k in COMPONENTS), key=lambda x: -abs(x[1]))
            e["change_why"] = [f"{k.capitalize()} {d:+.0f}" for k, d in deltas[:3] if abs(d) >= 3]
    if save and ranked:
        con.execute("DELETE FROM rankings WHERE run_id=? AND mode=?", (run_id, mode))
        con.executemany("INSERT INTO rankings VALUES(?,?,?,?,?,?)", [(run_id, mode, e["ticker"], e["rank"], e["opportunity"], json.dumps(e["subs"])) for e in ranked[:150]])
        con.commit()
    ranked_public = [{k: v for k, v in e.items() if k != "rank_score"} for e in ranked[:top_n]]
    return dict(mode=mode, mode_label=MODES[mode]["label"], scan_time=now_iso(), analyzed=bd["analyzed"], eligible=len(base), ranked_count=len(ranked),
                filtered_out=bd["analyzed"] - len(ranked), filter_reasons={**excl, **gated}, market=market, sectors=sectors,
                top10=ranked_public[:10], more=ranked_public[10:], status=data_status(cfg), previous_run=prev,
                commentary=commentary(market, sectors, ranked))


def commentary(market, sectors, ranked):
    if not market or market["condition"] == "Unavailable": return "No analyzed data yet."
    spy = next((i for i in market["indices"] if i["symbol"] == "SPY" and i["available"]), None)
    parts = []
    if spy and spy["sma50"] and spy["sma200"]:
        parts.append(f"The S&P 500 proxy (SPY) closed at {spy['close']:.2f}, {'above' if spy['close'] > spy['sma50'] else 'below'} its 50-day and {'above' if spy['close'] > spy['sma200'] else 'below'} its 200-day average.")
    parts.append(f"{market['breadth50']:.0f}% of analyzed stocks trade above their 50-day average ({market['breadth200']:.0f}% above the 200-day) — a {market['condition'].lower()} backdrop.")
    if len(sectors) >= 4:
        parts.append(f"Strongest sectors by 3-month momentum: {sectors[0]['sector']} and {sectors[1]['sector']}. Weakest: {sectors[-1]['sector']} and {sectors[-2]['sector']}.")
    parts.append({"Bullish": "Conditions broadly support new positions, but position size and stops still matter.",
                  "Neutral": "Conditions are mixed — favor high-confidence setups with strong risk/reward and keep position sizes moderate.",
                  "Bearish": "Conditions are defensive — consider reducing risk, tighter stops and fewer new positions; scores are penalized in this regime."}[market["condition"]])
    return " ".join(parts)


def stock_detail(cfg, ticker, mode="balanced"):
    bd = get_base(cfg)
    b = next((x for x in bd["base"] if x["ticker"] == ticker), None)
    if not b: return None
    market = market_overview(cfg, bd["base"]); sectors = sector_table(bd["base"])
    ss = {s["sector"]: s["strength"] for s in sectors}
    e = evaluate(b, mode if mode in MODES else "balanced", market["condition"], ss.get(b["sector"]))
    e.pop("rank_score", None)
    t = b["tech"]; n = len(b["closes"])
    sm50, sm200 = sma_series(b["closes"], 50), sma_series(b["closes"], 200)
    fm = {k: (r1(v) if isinstance(v, float) else v) for k, v in b["fm"].items() if k != "history"}
    e.update(dict(
        series=dict(dates=b["dates"], close=b["closes"], vol=b["vols"], sma50=sm50, sma200=sm200),
        tech={k: (r1(v) if isinstance(v, float) else v) for k, v in t.items() if k not in ("supports", "resistances", "macd")},
        macd={k: round(v, 3) for k, v in t["macd"].items()}, fund=fm, history=b["fm"]["history"], sector_pe=r1(b["sector_pe"]),
        analyst=b["analyst"], news=b["news"], earn_date=b["earn_date"], fund_fetched=b["fund_fetched"], analyst_fetched=b["analyst_fetched"], beta=r1(b["beta"])))
    return e
