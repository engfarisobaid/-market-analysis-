"""Local SQLite storage + config loading."""
import json, os, sqlite3, datetime as dt

ROOT = os.path.dirname(os.path.abspath(__file__))

DEFAULTS = {
    "sec_user_agent": "YourName your.email@example.com",
    "finnhub_api_key": "",
    "db_path": "data/scanner.db",
    "inbox_dir": "data/inbox",
    "min_price": 5,
    "min_avg_dollar_volume": 5_000_000,
    "max_stale_days": 10,
    "fundamentals_max_age_days": 7,
    "finnhub_candidates": 80,
    "port": 8765,
}

SCHEMA = """
CREATE TABLE IF NOT EXISTS universe(ticker TEXT PRIMARY KEY, name TEXT, exchange TEXT, is_etf INT, cik TEXT, sector TEXT, industry TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS prices(ticker TEXT, date TEXT, open REAL, high REAL, low REAL, close REAL, volume REAL, PRIMARY KEY(ticker,date));
CREATE TABLE IF NOT EXISTS fundamentals(ticker TEXT PRIMARY KEY, data TEXT, fiscal_end TEXT, fetched TEXT);
CREATE TABLE IF NOT EXISTS analyst(ticker TEXT PRIMARY KEY, data TEXT, fetched TEXT);
CREATE TABLE IF NOT EXISTS news(ticker TEXT PRIMARY KEY, data TEXT, fetched TEXT);
CREATE TABLE IF NOT EXISTS quotes(ticker TEXT PRIMARY KEY, price REAL, ts TEXT, fetched TEXT);
CREATE TABLE IF NOT EXISTS rankings(run_id TEXT, mode TEXT, ticker TEXT, rank INT, opportunity REAL, subs TEXT, PRIMARY KEY(run_id,mode,ticker));
CREATE TABLE IF NOT EXISTS watchlist(ticker TEXT PRIMARY KEY, added TEXT, score_at_add REAL, price_at_add REAL);
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
"""


def load_config():
    cfg = dict(DEFAULTS)
    p = os.path.join(ROOT, "config.json")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            cfg.update(json.load(f))
    for k in ("db_path", "inbox_dir"):
        if not os.path.isabs(cfg[k]):
            cfg[k] = os.path.join(ROOT, cfg[k])
    return cfg


def connect(cfg):
    os.makedirs(os.path.dirname(cfg["db_path"]), exist_ok=True)
    con = sqlite3.connect(cfg["db_path"], timeout=60, check_same_thread=False)
    con.executescript(SCHEMA)
    return con


def now_iso():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def set_meta(con, k, v):
    con.execute("INSERT INTO meta(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    con.commit()


def get_meta(con, k, default=None):
    r = con.execute("SELECT value FROM meta WHERE key=?", (k,)).fetchone()
    return r[0] if r else default


def age_days(iso):
    try:
        return (dt.datetime.now() - dt.datetime.fromisoformat(iso)).total_seconds() / 86400
    except Exception:
        return 9999
