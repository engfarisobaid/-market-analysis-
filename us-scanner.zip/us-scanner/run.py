import webbrowser, threading, server
threading.Timer(1.0, lambda: webbrowser.open(f"http://localhost:{server.CFG['port']}")).start()
server.main()
