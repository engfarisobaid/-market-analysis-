"""Local web server: JSON API + static UI.  Run: python run.py"""
import json, mimetypes, os, threading, urllib.parse
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from db import load_config, connect, now_iso, ROOT
import analysis, update

CFG = load_config()
LOCK = threading.Lock()
WEB = os.path.join(ROOT, "web")


class H(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def _send(self, obj, code=200):
        body = json.dumps(obj, default=str).encode("utf-8")
        self.send_response(code); self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n) or b"{}") if n else {}

    def do_GET(self): self.route("GET")
    def do_POST(self): self.route("POST")
    def do_DELETE(self): self.route("DELETE")

    def route(self, method):
        u = urllib.parse.urlparse(self.path); q = urllib.parse.parse_qs(u.query); p = u.path
        mode = (q.get("mode") or ["balanced"])[0]
        try:
            if p == "/api/scan":
                with LOCK: return self._send(analysis.run_scan(CFG, mode, save=(method == "POST")))
            if p.startswith("/api/stock/"):
                with LOCK: d = analysis.stock_detail(CFG, urllib.parse.unquote(p.split("/")[-1]).upper(), mode)
                return self._send(d if d else {"error": "No analyzable data for this ticker (missing prices/fundamentals or filtered out)."}, 200 if d else 404)
            if p == "/api/status":
                return self._send(dict(data=analysis.data_status(CFG), job=update.JOB))
            if p == "/api/update" and method == "POST":
                steps = self._body().get("steps") or ["universe", "prices", "fundamentals", "finnhub"]
                if update.JOB["running"]: return self._send({"error": "An update is already running"}, 409)
                threading.Thread(target=update.run_update, args=(CFG, steps), daemon=True).start()
                return self._send({"started": True})
            if p == "/api/watchlist":
                con = connect(CFG)
                if method == "POST":
                    t = self._body().get("ticker", "").upper()
                    d = analysis.stock_detail(CFG, t, mode)
                    con.execute("INSERT OR IGNORE INTO watchlist VALUES(?,?,?,?)", (t, now_iso(), d["opportunity"] if d else None, d["price"] if d else None)); con.commit()
                if method == "DELETE":
                    con.execute("DELETE FROM watchlist WHERE ticker=?", ((q.get("ticker") or [""])[0].upper(),)); con.commit()
                items = []
                for t, added, sc, px in con.execute("SELECT ticker,added,score_at_add,price_at_add FROM watchlist ORDER BY added"):
                    with LOCK: d = analysis.stock_detail(CFG, t, mode)
                    if d:
                        items.append(dict(ticker=t, name=d["name"], price=d["price"], price_date=d["price_date"], opportunity=d["opportunity"], confidence=d["confidence"],
                                          score_at_add=sc, score_change=(round(d["opportunity"] - sc, 1) if sc is not None else None),
                                          price_change=(round((d["price"] / px - 1) * 100, 1) if px else None), plan=d["plan"], risk_label=d["risk_label"], added=added))
                    else:
                        items.append(dict(ticker=t, name=t, unavailable=True, added=added))
                return self._send(items)
            if p == "/api/alerts":
                with LOCK: return self._send(build_alerts(mode))
            return self.static(p)
        except Exception as e:
            return self._send({"error": f"{type(e).__name__}: {e}"}, 500)

    def static(self, p):
        p = "/index.html" if p in ("/", "") else p
        fp = os.path.normpath(os.path.join(WEB, p.lstrip("/")))
        if not fp.startswith(WEB) or not os.path.isfile(fp):
            self.send_response(404); self.end_headers(); return
        data = open(fp, "rb").read()
        self.send_response(200); self.send_header("Content-Type", mimetypes.guess_type(fp)[0] or "application/octet-stream")
        self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)


def build_alerts(mode):
    sc = analysis.run_scan(CFG, mode, top_n=60)
    pool = sc["top10"] + sc["more"]
    out = []
    bd = analysis.get_base(CFG)["base"]; by = {b["ticker"]: b for b in bd}
    wl = [r[0] for r in connect(CFG).execute("SELECT ticker FROM watchlist")]
    tick = list(dict.fromkeys([e["ticker"] for e in pool] + wl))
    for t in tick:
        b = by.get(t)
        if not b: continue
        x, tc, an = b["tech"], b["tech"], b["analyst"]
        add = lambda kind, tone, msg: out.append(dict(ticker=t, kind=kind, tone=tone, msg=msg))
        if tc["breakout_confirmed"]: add("Breakout", "good", f"Closed above its 20-day high on {tc['relvol']:.1f}x average volume")
        if tc["breakdown"]: add("Breakdown", "bad", "Closed below its 20-day low")
        if tc["relvol"] and tc["relvol"] >= 2.0: add("Unusual Volume", "warn", f"Volume {tc['relvol']:.1f}x the 50-day average")
        if tc["rsi"] < 30: add("RSI Oversold", "warn", f"RSI {tc['rsi']:.0f}")
        if tc["rsi"] > 75: add("RSI Overbought", "warn", f"RSI {tc['rsi']:.0f}")
        if tc["macd_cross_up"]: add("MACD Bullish Crossover", "good", "MACD histogram turned positive")
        if tc["macd_cross_dn"]: add("MACD Bearish Crossover", "bad", "MACD histogram turned negative")
        if an and an["drift"] >= 0.15: add("Analyst Upgrade Trend", "good", "Consensus rating improved vs the previous month")
        if an and an["drift"] <= -0.15: add("Analyst Downgrade Trend", "bad", "Consensus rating deteriorated vs the previous month")
        if b["earn_days"] is not None and b["earn_days"] <= 7: add("Earnings Soon", "warn", f"Earnings in {b['earn_days']} days ({b['earn_date']})")
    for e in pool:
        if e.get("score_change") is not None and abs(e["score_change"]) >= 8:
            out.append(dict(ticker=e["ticker"], kind="SCORE CHANGE ALERT", tone="good" if e["score_change"] > 0 else "bad",
                            msg=f"Opportunity score {e['score_change']:+.0f} since last saved scan" + (f" — drivers: {', '.join(e['change_why'])}" if e["change_why"] else "")))
        if e.get("rank_change") and abs(e["rank_change"]) >= 5:
            out.append(dict(ticker=e["ticker"], kind="Rank Change", tone="good" if e["rank_change"] > 0 else "bad",
                            msg=f"{'↑' if e['rank_change'] > 0 else '↓'} {abs(e['rank_change'])} positions (#{e['prev_rank']} → #{e['rank']})"))
    return out[:120]


def main():
    port = CFG["port"]
    print(f"US Opportunity Scanner running at http://localhost:{port}  (Ctrl+C to stop)")
    ThreadingHTTPServer(("127.0.0.1", port), H).serve_forever()


if __name__ == "__main__":
    main()
