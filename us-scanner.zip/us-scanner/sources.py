"""Data provider layer: every external source lives here.
Swap or extend these functions to change providers; analysis/UI never call the network."""
import io, json, re, time, zipfile, datetime as dt
import requests
from db import connect, now_iso, set_meta, age_days

NASDAQ_URL = "https://www.nasdaqtrader.com/dynamic/SymDir/nasdaqlisted.txt"
OTHER_URL = "https://www.nasdaqtrader.com/dynamic/SymDir/otherlisted.txt"
SEC_TICKERS = "https://www.sec.gov/files/company_tickers.json"
SEC_FACTS = "https://data.sec.gov/api/xbrl/companyfacts/CIK{cik}.json"
SEC_SUBS = "https://data.sec.gov/submissions/CIK{cik}.json"
FINNHUB = "https://finnhub.io/api/v1"
MARKET_ETFS = ["SPY", "QQQ", "DIA", "IWM"]
BAD_NAME = re.compile(r"warrant|\brights?\b|\bunits?\b|preferred|depositary|\bnotes?\b|\btrust\b|\bfund\b|acquisition corp|\betf\b|\betn\b|%|debenture", re.I)


def norm(t):
    return re.sub(r"[^A-Z0-9]", "", t.upper())


# ------------------------------------------------------------------ universe
def load_universe(cfg, log=print):
    ua = {"User-Agent": cfg["sec_user_agent"]}
    rows = {}
    log("Downloading NASDAQ/NYSE symbol directories...")
    r = requests.get(NASDAQ_URL, timeout=60, headers=ua); r.raise_for_status()
    for line in r.text.splitlines()[1:]:
        p = line.split("|")
        if len(p) < 7 or p[0].startswith("File Creation"):
            continue
        sym, name, _cat, test, _fin, _lot, etf = p[:7]
        if test == "Y":
            continue
        rows[sym] = (sym, name, "NASDAQ", 1 if etf == "Y" else 0)
    r = requests.get(OTHER_URL, timeout=60, headers=ua); r.raise_for_status()
    ex_names = {"N": "NYSE", "A": "NYSE American", "P": "NYSE Arca", "Z": "BATS", "V": "IEX"}
    for line in r.text.splitlines()[1:]:
        p = line.split("|")
        if len(p) < 8 or p[0].startswith("File Creation"):
            continue
        act, name, exch, _cqs, etf, _lot, test, _nas = p[:8]
        if test == "Y" or exch not in ex_names:
            continue
        rows.setdefault(act, (act, name, ex_names[exch], 1 if etf == "Y" else 0))
    keep = []
    for sym, name, exch, etf in rows.values():
        if "$" in sym:
            continue
        if etf:
            if sym in MARKET_ETFS:
                keep.append((sym, name, exch, 1))
            continue
        if BAD_NAME.search(name):
            continue
        keep.append((sym, name, exch, 0))
    log(f"Symbols kept after filtering: {len(keep)}")
    log("Downloading SEC ticker -> CIK map...")
    r = requests.get(SEC_TICKERS, timeout=60, headers=ua); r.raise_for_status()
    cik = {norm(v["ticker"]): str(v["cik_str"]).zfill(10) for v in r.json().values()}
    con = connect(cfg)
    ts = now_iso()
    con.executemany(
        "INSERT INTO universe(ticker,name,exchange,is_etf,cik,updated) VALUES(?,?,?,?,?,?) "
        "ON CONFLICT(ticker) DO UPDATE SET name=excluded.name, exchange=excluded.exchange, is_etf=excluded.is_etf, cik=excluded.cik, updated=excluded.updated",
        [(s, n, e, f, cik.get(norm(s)), ts) for s, n, e, f in keep])
    con.commit()
    set_meta(con, "universe_updated", ts)
    log("Universe saved.")


# -------------------------------------------------------------------- prices
def parse_bars(text):
    lines = text.splitlines()
    if not lines:
        return []
    head = [h.strip().strip("<>").lower() for h in lines[0].split(",")]
    need = ("date", "open", "high", "low", "close")
    if not all(k in head for k in need):
        return []
    idx = {k: head.index(k) for k in need}
    vol = head.index("vol") if "vol" in head else (head.index("volume") if "volume" in head else None)
    out = []
    for ln in lines[1:]:
        p = ln.split(",")
        try:
            d = p[idx["date"]].strip()
            if len(d) == 8 and d.isdigit():
                d = f"{d[:4]}-{d[4:6]}-{d[6:]}"
            o, h, l, c = (float(p[idx[k]]) for k in ("open", "high", "low", "close"))
            v = float(p[vol]) if vol is not None and p[vol].strip() else 0.0
        except (ValueError, IndexError):
            continue
        if c > 0 and h > 0 and l > 0:
            out.append((d, o, h, l, c, v))
    out.sort()
    return out


def import_stooq_zip(path, cfg, log=print, keep=420):
    """Import the daily US bulk ZIP downloaded manually from https://stooq.com/db/h/ ."""
    con = connect(cfg)
    uni = {norm(r[0]): r[0] for r in con.execute("SELECT ticker FROM universe")}
    if not uni:
        raise RuntimeError("Universe is empty - run the 'universe' step first.")
    n_tick = 0
    latest = ""
    with zipfile.ZipFile(path) as z:
        names = [n for n in z.namelist() if n.lower().endswith(".txt")]
        log(f"ZIP contains {len(names)} files; matching against {len(uni)} symbols...")
        for i, name in enumerate(names):
            base = name.rsplit("/", 1)[-1]
            low = base.lower()
            if ".us" not in low and "/us/" not in name.lower():
                continue
            t = uni.get(norm(base.split(".")[0]))
            if not t:
                continue
            bars = parse_bars(z.read(name).decode("utf-8", "ignore"))[-keep:]
            if not bars:
                continue
            con.executemany("INSERT OR REPLACE INTO prices VALUES(?,?,?,?,?,?,?)", [(t,) + b for b in bars])
            n_tick += 1
            latest = max(latest, bars[-1][0])
            if n_tick % 300 == 0:
                con.commit()
                log(f"  imported {n_tick} tickers...")
    if latest:
        cutoff = (dt.date.fromisoformat(latest) - dt.timedelta(days=620)).isoformat()
        con.execute("DELETE FROM prices WHERE date < ?", (cutoff,))
    con.commit()
    set_meta(con, "prices_last_import", now_iso())
    set_meta(con, "prices_last_date", latest)
    log(f"Prices imported for {n_tick} tickers. Latest bar date: {latest or 'n/a'}")
    return n_tick


# -------------------------------------------------------------- SEC fundamentals
def _d(s):
    return dt.date.fromisoformat(s)


def _annual(facts, tags, unit="USD"):
    merged = {}
    for tag in tags:
        node = facts.get("us-gaap", {}).get(tag)
        if not node:
            continue
        per = {}
        for e in node.get("units", {}).get(unit, []):
            if e.get("fp") != "FY" or not str(e.get("form", "")).startswith("10-K"):
                continue
            s, en = e.get("start"), e.get("end")
            if not s or not en:
                continue
            try:
                days = (_d(en) - _d(s)).days
            except ValueError:
                continue
            if not 340 <= days <= 380:
                continue
            cur = per.get(en)
            if cur is None or e.get("filed", "") > cur[1]:
                per[en] = (e.get("val"), e.get("filed", ""))
        for en, (val, _f) in per.items():
            merged.setdefault(en, val)
    return sorted(merged.items(), reverse=True)


def _instant(facts, tags, unit="USD"):
    best = None
    for tag in tags:
        node = facts.get("us-gaap", {}).get(tag)
        if not node:
            continue
        for e in node.get("units", {}).get(unit, []):
            if e.get("end") and e.get("val") is not None and (best is None or (e["end"], e.get("filed", "")) > (best[0], best[2])):
                best = (e["end"], e["val"], e.get("filed", ""))
        if best:
            break
    return (best[0], best[1]) if best else None


def parse_companyfacts(js):
    f = js.get("facts", {})
    rev = _annual(f, ["Revenues", "RevenueFromContractWithCustomerExcludingAssessedTax", "SalesRevenueNet", "RevenueFromContractWithCustomerIncludingAssessedTax", "SalesRevenueGoodsNet"])
    ni = _annual(f, ["NetIncomeLoss", "ProfitLoss"])
    gp = _annual(f, ["GrossProfit"])
    op = _annual(f, ["OperatingIncomeLoss"])
    eps = _annual(f, ["EarningsPerShareDiluted", "EarningsPerShareBasicAndDiluted", "EarningsPerShareBasic"], "USD/shares")
    ocf = _annual(f, ["NetCashProvidedByUsedInOperatingActivities"])
    capex = _annual(f, ["PaymentsToAcquirePropertyPlantAndEquipment", "PaymentsToAcquireProductiveAssets"])
    buyback = _annual(f, ["PaymentsForRepurchaseOfCommonStock"])
    div = _annual(f, ["PaymentsOfDividends", "PaymentsOfDividendsCommonStock"])
    shw = _annual(f, ["WeightedAverageNumberOfDilutedSharesOutstanding", "WeightedAverageNumberOfSharesOutstandingBasic"], "shares")
    anchor = (rev or ni or eps)
    if not anchor:
        return {"unavailable": True}
    end = anchor[0][0]

    def at(series, e=None, back=0):
        e = e or end
        ds = dict(series)
        if back == 0:
            return ds.get(e)
        prev = [k for k in ds if 330 <= (_d(e) - _d(k)).days <= 400] if back == 1 else [k for k in ds if 690 <= (_d(e) - _d(k)).days <= 770]
        return ds[prev[0]] if prev else None

    dei = f.get("dei", {}).get("EntityCommonStockSharesOutstanding", {}).get("units", {}).get("shares", [])
    shares_out = sorted(dei, key=lambda e: e.get("end", ""))[-1]["val"] if dei else None
    equity = _instant(f, ["StockholdersEquity", "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"])
    debt = _instant(f, ["LongTermDebt", "LongTermDebtNoncurrent"])
    out = {
        "fiscal_end": end,
        "revenue": at(rev), "revenue_prev": at(rev, back=1), "revenue_2y": at(rev, back=2),
        "net_income": at(ni), "gross_profit": at(gp), "operating_income": at(op),
        "eps": at(eps), "eps_prev": at(eps, back=1),
        "ocf": at(ocf), "capex": at(capex), "buyback": at(buyback), "dividends": at(div),
        "shares_w": at(shw), "shares_w_prev": at(shw, back=1), "shares_out": shares_out,
        "equity": equity[1] if equity else None,
        "debt": debt[1] if debt else None,
        "liabilities": (_instant(f, ["Liabilities"]) or (0, None))[1],
        "assets": (_instant(f, ["Assets"]) or (0, None))[1],
        "cash": (_instant(f, ["CashAndCashEquivalentsAtCarryingValue", "CashCashEquivalentsAndShortTermInvestments"]) or (0, None))[1],
        "current_assets": (_instant(f, ["AssetsCurrent"]) or (0, None))[1],
        "current_liabilities": (_instant(f, ["LiabilitiesCurrent"]) or (0, None))[1],
        "history": [{"end": e, "revenue": v, "net_income": dict(ni).get(e), "eps": dict(eps).get(e)} for e, v in (rev[:5] if rev else [])],
    }
    return out


def sector_from_sic(sic, desc=""):
    try:
        s = int(sic)
    except (TypeError, ValueError):
        return "Other"
    if s in (1311, 1381, 1382, 1389) or 2900 <= s <= 2999 or s in (4610, 4612, 4613):
        return "Energy"
    if 1000 <= s <= 1499 or 2400 <= s <= 2499 or 2600 <= s <= 2699 or 3200 <= s <= 3399 or (2800 <= s <= 2899 and s not in (2833, 2834, 2835, 2836)):
        return "Materials"
    if s in (2833, 2834, 2835, 2836, 3841, 3842, 3843, 3844, 3845, 3851, 8731) or 8000 <= s <= 8099:
        return "Healthcare"
    if s == 3674:
        return "Semiconductors"
    if 3570 <= s <= 3579 or 3660 <= s <= 3679 or 3820 <= s <= 3829 or 7370 <= s <= 7379 or s in (3576, 3577, 3661, 3663, 3669):
        return "Technology"
    if 4800 <= s <= 4899 or 7800 <= s <= 7999 or 2700 <= s <= 2799:
        return "Communication"
    if 4900 <= s <= 4999:
        return "Utilities"
    if 6500 <= s <= 6599 or s == 6798:
        return "Real Estate"
    if 6000 <= s <= 6799:
        return "Financials"
    if 2000 <= s <= 2199 or s in (5140, 5141, 5400, 5411, 5412, 5122):
        return "Consumer Staples"
    if 2200 <= s <= 2399 or 3000 <= s <= 3199 or s in (3711, 3713, 3714) or 3900 <= s <= 3999 or 5200 <= s <= 5999 or 7000 <= s <= 7099 or 7200 <= s <= 7299 or 7500 <= s <= 7599:
        return "Consumer Discretionary"
    if 1500 <= s <= 1799 or 3400 <= s <= 3569 or 3580 <= s <= 3659 or 3680 <= s <= 3799 or 3800 <= s <= 3899 or 4000 <= s <= 4799 or 5000 <= s <= 5199 or 7300 <= s <= 7369 or 8700 <= s <= 8799:
        return "Industrials"
    return "Other"


def _get_json(sess, url, tries=4):
    for k in range(tries):
        try:
            r = sess.get(url, timeout=60)
        except requests.RequestException:
            time.sleep(3 * (k + 1)); continue
        if r.status_code == 404:
            return None
        if r.status_code in (429, 500, 502, 503, 504):
            time.sleep(6 * (k + 1)); continue
        r.raise_for_status()
        return r.json()
    return None


def fetch_fundamentals(cfg, tickers, log=print, progress=None, force=False):
    con = connect(cfg)
    sess = requests.Session()
    sess.headers.update({"User-Agent": cfg["sec_user_agent"], "Accept-Encoding": "gzip, deflate"})
    max_age = cfg["fundamentals_max_age_days"]
    todo = []
    for t in tickers:
        row = con.execute("SELECT fetched FROM fundamentals WHERE ticker=?", (t,)).fetchone()
        if force or not row or age_days(row[0]) >= max_age:
            todo.append(t)
    log(f"Fundamentals: {len(todo)} of {len(tickers)} tickers need a refresh (others are fresh).")
    for i, t in enumerate(todo):
        cik = (con.execute("SELECT cik FROM universe WHERE ticker=?", (t,)).fetchone() or [None])[0]
        data, sic = {"unavailable": True}, None
        if cik:
            js = _get_json(sess, SEC_FACTS.format(cik=cik))
            time.sleep(0.13)
            if js:
                data = parse_companyfacts(js)
            sub = _get_json(sess, SEC_SUBS.format(cik=cik))
            time.sleep(0.13)
            if sub:
                sic = sub.get("sic")
                con.execute("UPDATE universe SET sector=?, industry=? WHERE ticker=?",
                            (sector_from_sic(sic), sub.get("sicDescription"), t))
        con.execute("INSERT OR REPLACE INTO fundamentals VALUES(?,?,?,?)", (t, json.dumps(data), data.get("fiscal_end"), now_iso()))
        if (i + 1) % 25 == 0:
            con.commit()
            log(f"  fundamentals {i + 1}/{len(todo)}")
            if progress: progress(i + 1, len(todo))
    con.commit()
    set_meta(con, "fundamentals_updated", now_iso())


# ------------------------------------------------------------------- Finnhub
class Finnhub:
    def __init__(self, key):
        self.key, self.last = key, 0.0

    def get(self, path, **params):
        for attempt in range(3):
            wait = 1.1 - (time.time() - self.last)
            if wait > 0:
                time.sleep(wait)
            self.last = time.time()
            r = requests.get(FINNHUB + path, params={**params, "token": self.key}, timeout=30)
            if r.status_code == 429:
                time.sleep(30); continue
            if r.status_code in (401, 403):
                raise PermissionError("Finnhub rejected the API key / endpoint not allowed on this plan")
            r.raise_for_status()
            return r.json()
        return None


def fetch_finnhub(cfg, tickers, log=print, progress=None, quotes_only=()):
    key = cfg.get("finnhub_api_key", "").strip()
    if not key:
        log("No Finnhub key configured - skipping analyst/news/earnings (those components will show 'Data unavailable').")
        return
    fh = Finnhub(key)
    con = connect(cfg)
    today = dt.date.today()
    for i, t in enumerate(tickers):
        try:
            rec = fh.get("/stock/recommendation", symbol=t) or []
            news = fh.get("/company-news", symbol=t, **{"from": (today - dt.timedelta(days=10)).isoformat(), "to": today.isoformat()}) or []
            cal = fh.get("/calendar/earnings", symbol=t, **{"from": today.isoformat(), "to": (today + dt.timedelta(days=120)).isoformat()}) or {}
            q = fh.get("/quote", symbol=t) or {}
        except PermissionError as e:
            log(str(e)); return
        except requests.RequestException as e:
            log(f"  {t}: skipped ({e})"); continue
        ts = now_iso()
        con.execute("INSERT OR REPLACE INTO analyst VALUES(?,?,?)", (t, json.dumps({"rec": rec[:3], "earnings": cal.get("earningsCalendar", [])[:3]}), ts))
        items = [{"headline": n.get("headline", ""), "source": n.get("source", ""), "url": n.get("url", ""), "time": n.get("datetime", 0)} for n in news[:25]]
        con.execute("INSERT OR REPLACE INTO news VALUES(?,?,?)", (t, json.dumps(items), ts))
        if q.get("c"):
            con.execute("INSERT OR REPLACE INTO quotes VALUES(?,?,?,?)", (t, q["c"], dt.datetime.fromtimestamp(q.get("t", 0)).isoformat(sep=" ") if q.get("t") else "", ts))
        con.commit()
        if (i + 1) % 10 == 0:
            log(f"  finnhub {i + 1}/{len(tickers)}")
            if progress: progress(i + 1, len(tickers))
    for t in quotes_only:
        try:
            q = fh.get("/quote", symbol=t) or {}
        except Exception:
            continue
        if q.get("c"):
            con.execute("INSERT OR REPLACE INTO quotes VALUES(?,?,?,?)", (t, q["c"], dt.datetime.fromtimestamp(q.get("t", 0)).isoformat(sep=" ") if q.get("t") else "", now_iso()))
    con.commit()
    set_meta(con, "finnhub_updated", now_iso())
