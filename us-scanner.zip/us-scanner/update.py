"""Data update orchestrator.  Usage:
   python update.py all | universe | prices [zip] | fundamentals | finnhub
"""
import glob, os, sys, json, datetime as dt
from db import load_config, connect, set_meta, now_iso
import sources, analysis

JOB = {"running": False, "step": "", "done": 0, "total": 0, "log": [], "error": None, "started": None, "finished": None}


def log(msg):
    print(msg, flush=True)
    JOB["log"].append(f"{dt.datetime.now():%H:%M:%S} {msg}")
    del JOB["log"][:-200]


def progress(done, total):
    JOB["done"], JOB["total"] = done, total


def liquid_tickers(cfg):
    con = connect(cfg)
    latest = con.execute("SELECT MAX(date) FROM prices").fetchone()[0]
    if not latest: return []
    since = (dt.date.fromisoformat(latest) - dt.timedelta(days=90)).isoformat()
    rows = con.execute(
        "SELECT p.ticker, AVG(p.close*p.volume), (SELECT close FROM prices q WHERE q.ticker=p.ticker ORDER BY date DESC LIMIT 1) "
        "FROM prices p JOIN universe u ON u.ticker=p.ticker WHERE u.is_etf=0 AND p.date>=? GROUP BY p.ticker", (since,)).fetchall()
    return [t for t, adv, px in rows if adv and px and adv >= cfg["min_avg_dollar_volume"] and px >= cfg["min_price"]]


def newest_zip(cfg):
    zs = glob.glob(os.path.join(cfg["inbox_dir"], "*.zip"))
    return max(zs, key=os.path.getmtime) if zs else None


def run_update(cfg, steps, zip_path=None):
    if JOB["running"]: return False
    JOB.update(running=True, error=None, started=now_iso(), finished=None, log=[], done=0, total=0)
    try:
        if ("universe" in steps or "fundamentals" in steps) and "YourName" in cfg["sec_user_agent"]:
            raise RuntimeError("Edit config.json first: set sec_user_agent to your real name and email (SEC requires it).")
        if "universe" in steps:
            JOB["step"] = "Symbol universe"; sources.load_universe(cfg, log)
        if "prices" in steps:
            JOB["step"] = "Prices (Stooq ZIP import)"
            z = zip_path or newest_zip(cfg)
            if not z: log(f"No ZIP found in {cfg['inbox_dir']} — download the daily US ZIP from https://stooq.com/db/h/ and put it there.")
            else:
                log(f"Importing {os.path.basename(z)}"); sources.import_stooq_zip(z, cfg, log)
        if "fundamentals" in steps:
            JOB["step"] = "Fundamentals (SEC EDGAR)"
            tk = liquid_tickers(cfg); log(f"{len(tk)} liquid tickers pass the price/volume screen.")
            sources.fetch_fundamentals(cfg, tk, log, progress)
        if "finnhub" in steps:
            JOB["step"] = "Analysts / news / earnings (Finnhub)"
            set_meta(connect(cfg), "data_stamp", now_iso())
            sc = analysis.run_scan(cfg, "balanced", top_n=cfg["finnhub_candidates"])
            top = [e["ticker"] for e in sc["top10"] + sc["more"]]
            wl = [r[0] for r in connect(cfg).execute("SELECT ticker FROM watchlist")]
            sources.fetch_finnhub(cfg, list(dict.fromkeys(top + wl)), log, progress, quotes_only=sources.MARKET_ETFS)
        set_meta(connect(cfg), "data_stamp", now_iso())
        JOB["step"] = "Done"; log("Update finished.")
    except Exception as e:
        JOB["error"] = f"{type(e).__name__}: {e}"; log("ERROR: " + JOB["error"])
    finally:
        JOB["running"] = False; JOB["finished"] = now_iso()
    return True


if __name__ == "__main__":
    cfg = load_config()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "all"
    steps = ["universe", "prices", "fundamentals", "finnhub"] if cmd == "all" else [cmd]
    run_update(cfg, steps, sys.argv[2] if cmd == "prices" and len(sys.argv) > 2 else None)
    if JOB["error"]: sys.exit(1)
